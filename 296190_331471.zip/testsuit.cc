/*!
  \file   testsuit.cc
  \author Nathann Morand et Felipe Ramirez
  \date   MARS 2022
  \brief  Implémentation du module de test avec la seconde fonction main() avec test
*/
#include <cstdio>
#include <iostream>
#include <stdexcept>
#include <array>
#include <bits/stdc++.h>
#include <vector>
#include <string>
#include <assert.h>
#include <memory>
#include "textstorage.h"
#include "squarecell.h"
#include "constantes.h"
#include "entity.h"

using namespace std;

bool assertTextstorage();
bool assertSquarecell();
bool assertEntity();
bool assertFourmi();
bool assertFourmilliere();
bool assertNourriture();

bool assertTextstorageReadtxt();
bool assertTextstorageWritetxt();

bool assertSquarecellPoint();
bool assertEntityEntity();
bool assertSquarecellSquarecell();

bool assertFilesTest();
string runCommand(const char* command);
bool stringFuzzyMatch(string str1, string str2);

int main()
{
    cout << "beginning unit test" << endl;
    assert(assertTextstorage());
    assert(assertSquarecell());
    assert(assertEntity());
    assert(assertFourmi());
    assert(assertFourmilliere());
    assert(assertNourriture());
    cout << "beginning integration test" << endl;
    assert(assertFilesTest());
    cout << "all test passed successfully" << endl;
    return 0;
}

bool assertTextstorage()
{
    assert(assertTextstorageReadtxt());
    assert(assertTextstorageWritetxt());
    cout << "-> textstorage done" << endl;
    return true;
}

bool assertSquarecell()
{
    assertSquarecellPoint();
    return true;
}

bool assertEntity()
{
    assertEntityEntity();
    return true;
}
bool assertFourmi()
{
    return true;
}
bool assertFourmilliere()
{
    return true;
}
bool assertNourriture()
{
    return true;
}

bool assertTextstorageReadtxt()
{
    string teststringfin = "0";
    vector<vector<string>> inputBuffer = readtxt("scenario/no_error_collector_move.txt");
    if(teststringfin == inputBuffer[inputBuffer.size() - 1][inputBuffer[inputBuffer.size() - 1].size() - 1])
    {
        return true;
    } else {
        cout << "expected : " << teststringfin <<endl;
        cout << "got : " << inputBuffer[inputBuffer.size() - 1][inputBuffer[inputBuffer.size() - 1].size() - 1] <<endl;
        cout << "number of line : " << inputBuffer.size() << endl;
        cout << "number of entry for this line 1 : " << inputBuffer[0].size() << endl;
        cout << "number of entry for this line 2 : " << inputBuffer[1].size() << endl;
        cout << "number of entry for this line 3 : " << inputBuffer[2].size() << endl;
        for(unsigned int i=0;i<inputBuffer[2].size();i++)
        {
            cout << inputBuffer[2][i] <<" "<< endl;
        }
        return false;
    }
}

bool assertTextstorageWritetxt()
{
    vector<vector<string>> teststring = {{"1","2","3"},{"4","560000","-6","2"}};
    string Stockage_fichiertxt = "scenario/test_ecriture.txt";
    writetxt(Stockage_fichiertxt, teststring);
    vector<vector<string>> inputBuffer = readtxt(Stockage_fichiertxt);
    bool passed = true;
    for(unsigned int i=0; i<teststring.size();i++)
    {
        for(unsigned int j=0; j<teststring[i].size();j++)
        {
            if(teststring[i][j] != inputBuffer[i][j])
            {
                passed = false;
            }
        }
    }
    if(passed)
    {
        return true;
    }else{
        cout << "expected : " + (teststring[0][0]) << endl;
        cout << "received : " + (inputBuffer[0][0]) << endl;
        cout << "expected : " + (teststring[0][2]) << endl;
        cout << "received : " + (inputBuffer[0][2]) << endl;
        cout << "expected : " + (teststring[1][2]) << endl;
        cout << "received : " + (inputBuffer[1][2]) << endl;
        cout << "expected : " + (teststring[1][3]) << endl;
        cout << "received : " + (inputBuffer[1][3]) << endl;
        return false;
    }
}

bool assertSquarecellPoint()
{
    Point testPoint = Point(1,3);
    assert(testPoint.getCoordX()==1);
    assert(testPoint.getCoordY()==3);
    return true;
}

bool assertEntityEntity()
{
    shared_ptr<Entity> testEnt = make_shared<Entity>(Point(2,4),1,1,'F',0);
    assert((*testEnt).getHeight()==1);
    assert((*testEnt).getWidth()==1);
    assert((*testEnt).getPosition().getCoordX()==2);
    assert((*testEnt).getPosition().getCoordY()==4);
    (*testEnt).setPosition(Point(5,6));
    assert((*testEnt).getPosition().getCoordX()==5);
    assert((*testEnt).getPosition().getCoordY()==6);
    (*testEnt).setSize(4,8);
    assert((*testEnt).getHeight()==4);
    assert((*testEnt).getWidth()==8);
    assert((*testEnt).getSpecie()=='F');
    return true;
}

bool assertFilesTest()
{
    cout << runCommand("make build") << endl; // force normal rebuild

    cout << "test 1 starting" << endl;
    string cmdExpected = "Please provide a file to load";
    string cmdResult =runCommand("./projet ");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 1 passed (./projet)" << endl;

    cout << "test 2 starting" << endl;
    cmdExpected = "Correct file";
    cmdResult = runCommand("./projet scenario/no_error_collector_move.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 2 passed (./projet scenario/no_error_collector_move.txt)" << endl;

    cout << "test 3 starting" << endl;
    cmdExpected = "Correct file";
    cmdResult = runCommand("./projet scenario/no_error_neighbours_anthill.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 3 passed (./projet scenario/no_error_neighbours_anthill.txt)" << endl;

    cout << "test 4 starting" << endl;
    cmdExpected = "collector with coordinates 14 18 overlaps with another exclusive entity at least on 15 17";
    cmdResult = runCommand("./projet scenario/error_collector_overlap.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 4 passed (./projet scenario/error_collector_overlap.txt)" << endl;

    cout << "test 5 starting" << endl;
    cmdExpected = "defensor with coordinates 101 117 is not fully within its home: 0";
    cmdResult = runCommand("./projet scenario/error_defensor_not_within_home.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 5 passed (./projet scenario/error_defensor_not_within_home.txt)" << endl;

    cout << "test 6 starting" << endl;
    cmdExpected = "home 0 overlaps with home 1";
    cmdResult = runCommand("./projet scenario/error_homes_overlap.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 6 passed (./projet scenario/error_homes_overlap.txt)" << endl;

    cout << "test 7 starting" << endl;
    cmdExpected = "home 0 overlaps with home 1";
    cmdResult = runCommand("./projet scenario/error_homes_overlap.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 7 passed (./projet scenario/error_homes_overlap.txt)" << endl;

    cout << "test 8 starting" << endl;
    cmdExpected = "collector with coordinates 14 18 overlaps with another exclusive entity at least on 15 17";
    cmdResult = runCommand("./projet scenario/t01.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 8 passed (./projet scenario/t01.txt)" << endl;

    cout << "test 9 starting" << endl;
    cmdExpected = "collector with coordinates 18 14 overlaps with another exclusive entity at least on 17 15";
    cmdResult = runCommand("./projet scenario/t02.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 9 passed (./projet scenario/t02.txt)" << endl;

    cout << "test 10 starting" << endl;
    cmdExpected = "defensor with coordinates 101 117 is not fully within its home: 0";
    cmdResult = runCommand("./projet scenario/t03.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 10 passed (./projet scenario/t03.txt)" << endl;

    cout << "test 11 starting" << endl;
    cmdExpected = "defensor with coordinates 118 102 is not fully within its home: 0";
    cmdResult = runCommand("./projet scenario/t04.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 11 passed (./projet scenario/t04.txt)" << endl;

    cout << "test 12 starting" << endl;
    cmdExpected = "defensor with coordinates 118 117 is not fully within its home: 0";
    cmdResult = runCommand("./projet scenario/t05.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 12 passed (./projet scenario/t05.txt)" << endl;

    cout << "test 13 starting" << endl;
    cmdExpected = "defensor with coordinates 101 102 is not fully within its home: 0";
    cmdResult = runCommand("./projet scenario/t06.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 13 passed (./projet scenario/t06.txt)" << endl;

    cout << "test 14 starting" << endl;
    cmdExpected = "defensor with coordinates 106 106 overlaps with another exclusive entity at least on 105 105";
    cmdResult = runCommand("./projet scenario/t07.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 14 passed (/projet scenario/t07.txt)" << endl;

    cout << "test 15 starting" << endl;
    cmdExpected = "food with coordinates 78 78 overlaps with another exclusive entity";
    cmdResult = runCommand("./projet scenario/t08.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 15 passed (./projet scenario/t08.txt)" << endl;

    cout << "test 16 starting" << endl;
    cmdExpected = "generator with coordinates 3 3 overlaps with another exclusive entity at least on 4 5";
    cmdResult = runCommand("./projet scenario/t09.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 16 passed (./projet scenario/t09.txt)" << endl;

    cout << "test 17 starting" << endl;
    cmdExpected = "predator with coordinates 22 24 overlaps with another exclusive entity";
    cmdResult = runCommand("./projet scenario/t10.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 17 passed (./projet scenario/t10.txt)" << endl;

    cout << "test 18 starting" << endl;
    cmdExpected = "generator with coordinates 11 5 is not fully within its home: 1";
    cmdResult = runCommand("./projet scenario/t11.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 18 passed (./projet scenario/t11.txt)" << endl;

    cout << "test 19 starting" << endl;
    cmdExpected = "home 0 overlaps with home 1";
    cmdResult = runCommand("./projet scenario/t12.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 19 passed (./projet scenario/t12.txt)" << endl;

    cout << "test 20 starting" << endl;
    cmdExpected = "coordinate 10000000 does not belong to [ 0, 127 ]";
    cmdResult = runCommand("./projet scenario/t13.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 20 passed (./projet scenario/t13.txt)" << endl;

    cout << "test 21 starting" << endl;
    cmdExpected = "combined coordinate 117 and square side 12 do not belong to [ 0, 127 ]";
    cmdResult = runCommand("./projet scenario/t14.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 21 passed (./projet scenario/t14.txt)" << endl;

    cout << "test 22 starting" << endl;
    cmdExpected = "Correct file";
    cmdResult = runCommand("./projet scenario/t15.txt");
    assert(stringFuzzyMatch(cmdExpected, cmdResult));
    cout << "test 22 passed (./projet scenario/t15.txt)" << endl;
    return true;
}

bool stringFuzzyMatch(string str1, string str2)
{
    if(!str1.empty())
    {
        if(str1[str1.length() - 1] == '\n')
        {
            str1.erase(str1.length() - 1);
        }
    }
    if(!str2.empty())
    {
        if(str2[str2.length() - 1] == '\n')
        {
            str2.erase(str2.length() - 1); //efface
        }
    }
    if(not(str2 == str1))
    {
        cout << "Expected :"+str1<<endl;
        cout << "got      :"+str2<<endl;
    }
    return (str2 == str1);
}

string runCommand(const char* command)
{
    string result;
    array<char, 128> outputBuffer;
    unique_ptr<FILE, decltype(&pclose)> pipe(popen(command, "r"), pclose);
    if(!pipe)
    {
        cout << "command failed" << endl;
        exit(0);
    }
    while(fgets(outputBuffer.data(), outputBuffer.size(), pipe.get()) != nullptr)
    {
        result += outputBuffer.data();
    }
    return result;
}

